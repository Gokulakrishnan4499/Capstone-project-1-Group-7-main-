import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  public adminregisterForm !:FormGroup;

  constructor(private formBuilder:FormBuilder, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.adminregisterForm=this.formBuilder.group({
      fullname:[''],
      email:[''],
      password:[''],
      mobile:['']

    })
  }
  adminregister(){

    this.http.post<any>("http://localhost:3000/registeradmin",this.adminregisterForm.value)
    .subscribe(res=>{
      alert("register successful");
      this.adminregisterForm.reset();
      this.router.navigate(['adminlogin']);
    
    },error=>{
      alert("something went wrong")
    }
    )
  }

}