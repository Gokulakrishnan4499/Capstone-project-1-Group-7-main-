import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { UserComponent } from './user/user.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import{MatToolbarModule} from '@angular/material/toolbar';
import { CrudoperationsComponent } from './crudoperations/crudoperations.component';
import { ItemComponent } from './item/item.component';
import { ItemlistComponent } from './itemlist/itemlist.component';
import { CartComponent } from './cart/cart.component';
import { FilterComponent } from './filter/filter.component';
import { ItemlistsComponent } from './itemlists/itemlists.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2OrderModule } from 'ng2-order-pipe';
import {NgxPaginationModule} from 'ngx-pagination';
import { SalesreportComponent } from './salesreport/salesreport.component';
 










@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    
    UserComponent,
    AdminregisterComponent,
    AdminloginComponent,
    CrudoperationsComponent,
    ItemComponent,
    ItemlistComponent,
    CartComponent,
    FilterComponent,
    ItemlistsComponent,
    SalesreportComponent
  

    
    
   
    

 
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatToolbarModule,
    Ng2SearchPipeModule,
    Ng2OrderModule,
    NgxPaginationModule
    
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
