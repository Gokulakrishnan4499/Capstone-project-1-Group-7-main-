import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { Itemmodel } from '../item/item.model';
import { ApiService } from '../item/api.service';
import { Router } from '@angular/router';
import { Itemlists } from '../itemlists/itemlists';



@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {
  itemlists:Itemlists[]=[];
  itemname:any;

  [x: string]: any;
  formvalue!:FormGroup;
  itemmodelobj: Itemmodel=new Itemmodel();
  itemdata!:any;
  showadd!:boolean;
  showupdate!:boolean;
  constructor(private formbuilder:FormBuilder,private api: ApiService,private router:Router) { }

  ngOnInit(): void {
    this.formvalue=this.formbuilder.group({
      itemname:[''],
      itemdesc:[''],
      itemprice:['']

    })
    this.getallitem();
  }
  cart(id:number,itemname:string,itemprice:string){
    alert(itemname+ " added to cart succesfully");
    console.log(itemname);
    console.log(itemprice);
   

    this.router.navigate(['cart'])
  }


  postitemdetails(){
    this.itemmodelobj.itemname=this.formvalue.value.itemname;
    this.itemmodelobj.itemdesc=this.formvalue.value.itemdesc;
    this.itemmodelobj.itemprice=this.formvalue.value.itemprice;

    this.api.postitem(this.itemmodelobj)
    .subscribe (res=>{
      console.log(res);
      alert("item added successfully");
      let ref=document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getallitem();
    },
    err=>{
      alert("something went wrong");
    }
    )

  }
  getallitem(){
    this.api.getitem()
    .subscribe(res=>{
      this.itemdata=res;
    })
  }
  deleteitem(row:any){
    this.api.deleteitem(row.id)
    .subscribe(res=>{
      alert("item deleted");
      this.getallitem();
     
    })
  }
  onedit(row:any){
    this.showadd=false;
    this.showupdate=true;

    this.itemmodelobj.id=row.id;
    this.formvalue.controls['itemname'].setValue(row.itemname);
    this.formvalue.controls['itemdesc'].setValue(row.itemdesc);
    this.formvalue.controls['itemprice'].setValue(row.itemprice);


  }
  updateitemdetails(){
    this.itemmodelobj.itemname=this.formvalue.value.itemname;
    this.itemmodelobj.itemdesc=this.formvalue.value.itemdesc;
    this.itemmodelobj.itemprice=this.formvalue.value.itemprice;
    this.api.updateitem(this.itemmodelobj,this.itemmodelobj.id)
    .subscribe(res=>{
      alert("updated successfully");
      let ref=document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getallitem();

    })

  }
  Search()
{
  if(this.itemname == "")
  {
    this.ngOnInit();

  }else{
    this.itemlists=this.itemlists.filter(res=>{
      return res.itemname.toLocaleLowerCase().match(this.itemname.toLocaleLowerCase());
    });
  }
}


}
