import { Component, OnInit } from '@angular/core';
import { Cart } from './cart';
import { RestService } from './rest.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart:Cart[]=[];
  itemname:any;

  constructor(public rs:RestService,private router:Router) { }

  ngOnInit(): void {
    this.rs.getCart().subscribe((response)=>{
      this.cart=response;
    });
  }
Search()
{
  if(this.itemname == "")
  {
    this.ngOnInit();

  }else{
    this.cart=this.cart.filter(res=>{
      return res.itemname.toLocaleLowerCase().match(this.itemname.toLocaleLowerCase());
    });
  }
}





}
