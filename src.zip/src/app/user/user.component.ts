import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { Usermodel } from './user.model';

import { ApiService } from './api.service';



@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  [x: string]: any;
  formvalue!:FormGroup;
  usermodelobj: Usermodel=new Usermodel();
  userdata!:any;
  showadd!:boolean;
  showupdate!:boolean;
  constructor(private formbuilder:FormBuilder,private api: ApiService) { }

  ngOnInit(): void {
    this.formvalue=this.formbuilder.group({
      email:[''],
      password:['']

    })
    this.getalluser();
  }
  clickadduser(){
    
    this.formvalue.reset();
    this.showadd=true;
    this.showupdate=false;
  }

  postuserdetails(){
    this.usermodelobj.email=this.formvalue.value.email;
    this.usermodelobj.password=this.formvalue.value.password;

    this.api.postuser(this.usermodelobj)
    .subscribe(res=>{
      console.log(res);
      alert("user added successfully");
      let ref=document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getalluser();
    },
    err=>{
      alert("something went wrong");
    }
    )

  }
  getalluser(){
    this.api.getuser()
    .subscribe(res=>{
      this.userdata=res;
    })
  }
  deleteuser(row:any){
    this.api.deleteuser(row.id)
    .subscribe(res=>{
      alert("user deleted");
      this.getalluser();
     
    })
  }
  onedit(row:any){
    this.showadd=false;
    this.showupdate=true;

    this.usermodelobj.id=row.id;
    this.formvalue.controls['email'].setValue(row.email);
    this.formvalue.controls['password'].setValue(row.password);


  }
  updateuserdetails(){
    this.usermodelobj.email=this.formvalue.value.email;
    this.usermodelobj.password=this.formvalue.value.password;
    this.api.updateuser(this.usermodelobj,this.usermodelobj.id)
    .subscribe(res=>{
      alert("updated successfully");
      let ref=document.getElementById('cancel')
      ref?.click();
      this.formvalue.reset();
      this.getalluser();

    })

  }

}
