export class Usermodel{
    id:number=0;
    email: string='';
    password: string='';
}