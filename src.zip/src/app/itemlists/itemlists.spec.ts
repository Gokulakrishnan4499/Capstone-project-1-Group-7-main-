import { Itemlists } from './itemlists';

describe('Itemlists', () => {
  it('should create an instance', () => {
    expect(new Itemlists()).toBeTruthy();
  });
});
