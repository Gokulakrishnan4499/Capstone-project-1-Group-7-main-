import { Component, OnInit } from '@angular/core';
import { Itemlists } from './itemlists';
import { RestService } from './rest.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-itemlists',
  templateUrl: './itemlists.component.html',
  styleUrls: ['./itemlists.component.css']
})
export class ItemlistsComponent implements OnInit {
  itemlists:Itemlists[]=[];
  itemname:any;

  constructor(public rs:RestService,private router:Router) { }

  ngOnInit(): void {
    this.rs.getItemlists().subscribe((response)=>{
      this.itemlists=response;
    });
  }
Search()
{
  if(this.itemname == "")
  {
    this.ngOnInit();

  }else{
    this.itemlists=this.itemlists.filter(res=>{
      return res.itemname.toLocaleLowerCase().match(this.itemname.toLocaleLowerCase());
    });
  }
}

cart(itemdesc:string,itemname:string,itemprice:string){
  alert(itemname+ " added to cart succesfully");
  console.log(itemname);
  console.log(itemprice);
 

  this.router.navigate(['cart'])
}


}
