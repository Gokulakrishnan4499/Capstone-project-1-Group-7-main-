export class Itemlists {
    id:number;
    itemname: string;
    itemdesc: string;
    itemprice:string;


    constructor(id:any,itemname:any,itemdesc:any,itemprice:any)
    {
        this.id=id;
        this.itemname=itemname;
        this.itemdesc=itemdesc;
        this.itemprice=itemprice
    }
}
