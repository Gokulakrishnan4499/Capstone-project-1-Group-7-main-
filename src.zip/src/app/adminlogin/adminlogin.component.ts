import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  public adminloginform!:FormGroup
  constructor(private formbuilder:FormBuilder,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.adminloginform=this.formbuilder.group({
      email:[''],
      password:['']

    })
  }
  adminlogin(){
    this.http.get<any>("http://localhost:3000/registeradmin")
    .subscribe(res=>{
     const user= res.find((a:any)=>{
       return a.email === this.adminloginform.value.email && a.password ===this.adminloginform.value.password
     
     });

     if(user){
       alert("Login success");
       this.adminloginform.reset();
       this.router.navigate(['crudoperations'])
      
     }
     else
     {
       alert("user not found");
       

     }
     
    },err=>{
      alert("something went wrong");
    })
  }

}
function next(next: any, arg1: () => void, arg2: (err: any) => void) {
  throw new Error('Function not implemented.');
}

