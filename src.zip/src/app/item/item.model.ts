export class Itemmodel{
    id:number=0;
    itemname: string='';
    itemdesc: string='';
    itemprice:string='';
}