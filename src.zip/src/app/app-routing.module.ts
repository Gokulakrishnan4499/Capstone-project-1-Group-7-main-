import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { UserComponent } from './user/user.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { CrudoperationsComponent } from './crudoperations/crudoperations.component';
import { ItemComponent } from './item/item.component';
import { ItemlistComponent } from './itemlist/itemlist.component';
import { CartComponent } from './cart/cart.component';
import { ItemlistsComponent } from './itemlists/itemlists.component';
import { SalesreportComponent } from './salesreport/salesreport.component';









const routes: Routes = [
//{path:'',redirectTo:'login',pathMatch:'full'},
{path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},

{path:'user',component:UserComponent},
{path:'adminlogin',component:AdminloginComponent},
{path:'adminregister',component:AdminregisterComponent},
{path:'crudoperations',component:CrudoperationsComponent},
{path:'item',component:ItemComponent},
{path:'itemlist',component:ItemlistComponent},
{path:'cart',component:CartComponent},
{path:'itemlists',component:ItemlistsComponent},
{path:'salesreport',component:SalesreportComponent}








];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
