import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesreport',
  templateUrl: './salesreport.component.html',
  styleUrls: ['./salesreport.component.css']
})
export class SalesreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
